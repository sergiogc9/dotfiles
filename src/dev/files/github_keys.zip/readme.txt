This is a fake zip, I am not making public my backup private config :).

See more info at:
https://github.com/sergiogc9/dotfiles
